#!/usr/bin/bash

node index.js